# Landing Page Project

## Table of Contents
* [info and about](#info)
* [editor](#Editor)
* [brief](#brief)
* [Instructions](#instructions)

## info

this landing project for © Udacity
based of Static version that downloaded from project page
## Editor
Ahmed Fawzy Elragal
mailto:elragal30@gmail.com

## brief
    * the project is a landing page that has 4 sections and can dynamically add sections (through button in nav bar max:9 sections )
    * the links in navbar generated automaticlly and dynamically through app.js (javascript).
    * Automaticlly get the active section & link and chang it style.
    * clicking on link will smoothly navigate to the section [css smooth]
    * there is also some animation and transition(when changeing active section)
    * added :
        - Logo image.
        - Button to add section easily.
        - button to return to top (smoothly).
    * All features are usable across modern desktop, tablet, and phone browsers. (if width is less than 480px the UL Menu will be viewd vertically with small font).
        
## Instructions
